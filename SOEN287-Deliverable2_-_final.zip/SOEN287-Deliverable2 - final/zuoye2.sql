-- creat tables :

Create Table USERS(
    username VARCHAR(20) PRIMARY key not null,
   	password VARCHAR(20) not null,
    name VARCHAR(30) not null, 
    email VARCHAR(40), 
    telephone VARCHAR(20), 
    address VARCHAR(50),
   	sold int    
);
CREATE table providers(
    username varchar(20) PRIMARY key not null,
   	password varchar(20) not null,
   	name varchar(20) not null,
   	email varchar(40),
   	telephone varchar(20),
   	address varchar(50)
);
Create Table Software(
   	name VARCHAR(20) not null,
   	version VARCHAR(20) not null,
    providername VARCHAR(20) not null, 
    price int,
    renew int,
   	PRIMARY key(`name` ,`version`)    
);
CREATE table sells(
    name varchar(20) not null,
   	version varchar(20) not null,
   	purchaseby VARCHAR(20) not null,
   	serialnumber VARCHAR(8) PRIMARY key not null,
   	purchasedate date,
   	activedate date,
   	validation boolean,
   	validuntil date,    
   	qufen varchar(4)
);
create table mail(
    fro varchar(20) not null,
   	too varchar(20) not null,
    reading boolean not null,
    date date,
    title varchar(100),
    text varchar(1000) PRIMARY key not null
    );

-- insert some data in every table except the mail table :

	insert into users values ('0000',"1234","April","april01@gmail.com","514-777-8989","22 Decarie",8000);
	insert into users values ('0001',"1234","Kenny","ken3@gmail.com","438-987-0000","398 St-Catherine",800);
   insert into users values ('0002',"1234","Nick","nickthebest@gmail.com","514-392-9273","77 Sherbrooke",800);
   insert into users values ('0003',"1234","Alston","onalst@gmail.com","514-212-2121","21 Jumpstreet",800);
   
	insert into providers values ('1000',"123","Oracle","1000@Oracle.com","123456789","gaspesie");
	insert into providers values ('1001',"123","Microsoft","1001@Microsoft.com","123456789","gaspesie");
    
   	 insert into software values("Office","03",'1001',130,100);
    insert into software values("Windows","95",'1001',70,55);
    insert into software values("Windows","Vista",'1001',140,110);
    insert into software values("Oracle","22",'1000',210,180);
    insert into software values("Office","97",'1001',100,90);
    insert into software values("Windows","98",'1001',100,90);
    insert into software values("Windows","XP",'1001',120,100);
    insert into software values("Oracle","19",'1000',200,170);
    
    insert into sells values ("Windows","98",'0000','93021222',"2008-06-29","2008-06-30",false,"2009-06-30","ACSO");
    insert into sells values ("Office","97",'0000','93021479',"2022-07-29","2022-07-29",false,"2023-07-29","LKJM");
    insert into sells values ("Windows","98",'0001','93021227',"2023-08-29","2023-08-30",true,"2024-08-30","KLPO");

